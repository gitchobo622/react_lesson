import styled from "@emotion/styled";

const MyButton = styled.button`
  & > span{
    color: red;
  }
  &:hover{
    background-color: red;
  }
  /*  주석 */
  background: none;
  cursor: pointer;
  padding: 5px 10px;
  border-radius: 6px;
  outline: none;
  border: none;
  color: blue;
  ${(props)=> props.variant === 'contained' &&  {color: 'white', backgroundColor:'blue', boxShadow:' 2px 2px 4px rgba(0,0,0,0.08)'}}

  ${(props)=> props.variant === 'outlined' && {border:'1px solid blue'}}
`;

const Component0201 = ()=>{
  return (
    <div className = "box">
      <h1>Component0201영역입니다</h1>
      <MyButton >1번종류</MyButton>
      <MyButton variant="contained">2<span>번종</span>류</MyButton>
      <MyButton variant="outlined">3번종류</MyButton>
      <h2 style={{color:'red', border:'1px solid silver'}}>인라인 스타일 주기</h2>
    </div>
  );
}

export default Component0201;