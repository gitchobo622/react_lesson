import { useState } from "react";


const Component0202 = ()=>{
  //코드
  let a = 10;
  const [ cnt , setCnt] = useState(0);
  
  const banana = ( e ) => {
    // 이벤트 발생시 실행되는 함수는 리액트가 자동으로 
    // 이벤트에 대한 정보를 매개변수에 넘겨준다
    console.log(e); // --> 발생한 이벤트에 대한 정보가 들어있는 객체
    console.log('안녕');
  }
  const minusHandler = ()=>{
    console.log('함수가 실행됨, 현재 a : ' , a);
    a--; // a = a - 1;
    setCnt( cnt - 1 );
    console.log('함수실행이 이제 종료될거임 현재 a:', a);
  }

  const plusHandler = ()=>{
    setCnt(cnt+1);
    // cnt = cnt + 1;
  }
  
  return(
    <div className="box">
      <h1>Component0202영역입니다</h1>
      <p>a에 들어있는 값 : {a}</p>
      <p>cnt에 들어있는 값 : {cnt}</p>
      <button onClick={minusHandler}>-</button>
      <button onClick={plusHandler}>+</button>
      <button onClick={banana}>클릭해 보세요!</button>
    </div>
  );
}

export default Component0202;