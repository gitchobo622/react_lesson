// 컴포넌트 만들기 
// 컴포넌트는 함수 입니다(과거에는 class 로 만들었음)

import { useState } from "react";
import Component0202 from "./pages/study/02-02state";
import Component01 from "./pages/study/01-01basic";
import Component0201 from "./pages/study/02-01emotion";

// 컴포넌트 이름은 반드시 대문자로 시작해야 합니다
const App = (  )=>{
  const [ target, setTarget ] = useState('01');

  const btn01 = ()=>{
    setTarget('01');
  }
  const btn0201 = ()=>{
    setTarget('0201');
  }
  const btn0202 = ()=>{
    setTarget('0202');
  }

  return (
    <div className='box'>
      <h1>App 영역입니다</h1>
      <button onClick={btn01}>01컴포넌트</button>
      <button onClick={btn0201}>0201컴포넌트</button>
      <button onClick={btn0202}>0202컴포넌트</button>
      { target === '01' ? <Component01/> : 
          target === '0201' ? <Component0201/> :
          <Component0202/>
      }
    </div> 
  )
}

export default App;