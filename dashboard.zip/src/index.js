import ReactDOM from 'react-dom/client';
import App from './App';
// css 는 import 할 때 주소만 import 하면 된다
import './index.css';

const root = ReactDOM.createRoot(document.querySelector('#root'));
root.render(
  <div className='box'>
    <h1 className="err">가상 DOM Root 속에 직접 그려짐</h1> 
    <p>이 공간은 Root 안에 div태그 한개를 그린 상태 입니다</p>
    <App />
  </div>
);